
/*
 * ASSIGNMENT 4
 * Title: Rock, Paper, Scissors
 * Variables: 
 * SUMMARY 
 * Important program elements used:
 1.
 2.
 3.
 4.
 5.
 6.
 7
 8.
 9.
 10.




 
 variables, Math.floor,   
 * .random, newDate (), 7 points UI/UX, switch(), 
 
 * prompt(), alert()
 * April, 2023
 * Partners: Will Jo, Ryan Liu, Simone, Ryan R.
 */




/*
summary: 
@parms: 
@return: 
*/

function playgame() {
  var userChoice;
  var computerChoice = getComputerChoice();
  
 
} //End of playGame function





function userInput () {
  var question = prompt("Enter Rock, Paper or scissors");
    
}

userInput = userInput.toLowerCase();

function getComputerChoice () {}
 var answers = [];

  
  answers[0] = "ROCK";
  answers[1] = "PAPER";
  answers[2] = "SCISSORS";
  

 


function randonNumberGen () {
  var randomNumber =

    
  return awnsers[randomNumber]
}





function determineWinner() {
if (userChoice === computerChoice) {
  console.log('The round ended in a tie.')
  
} else if (userChoice === ROCK) && (computerChoice == PAPER) {
  console.log('You Lose!!!');
  
} else if (userChoice === SCISSORS ) && (computerChoice == PAPER) {
  console.log('You Lose!!!');

  
  
  

  
}
  return
}




}

else if (userInput == SCISSORS) {

  console.log();
}
  
 
//Beginning of Program 
 //Title

//Variable declaration


//User interface


//Beginning of main



/* 
*
*/



//End of the Main 




//User Interface Continuation
//thank you statetent


//
/*
 * End of Program
 * Notes:
 * we could add date and genral ui text, and while(), and prompts
 * function randonNumberGen ()
 
 */






